package com.example.jsonvalidation.service;

import com.example.jsonvalidation.exception.SchemaValidationException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.networknt.schema.JsonSchema;
import com.networknt.schema.ValidationMessage;
import org.springframework.stereotype.Service;

import java.util.Set;

@Service
public class LoanService {
    private final JsonSchema schema;
    private final ObjectMapper objectMapper;

    public LoanService(JsonSchema schema, ObjectMapper objectMapper) {
        this.schema = schema;
        this.objectMapper = objectMapper;
    }

    public void validate(String jsonPayload) throws Exception {
        JsonNode jsonNode = objectMapper.readTree(jsonPayload);
        Set<ValidationMessage> errors = schema.validate(jsonNode);
        if (!errors.isEmpty()) {
            throw new SchemaValidationException(errors);
        }
    }
}
