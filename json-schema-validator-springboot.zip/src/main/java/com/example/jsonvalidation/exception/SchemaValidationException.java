package com.example.jsonvalidation.exception;

import com.networknt.schema.ValidationMessage;
import java.util.Set;

public class SchemaValidationException extends RuntimeException {
    private final Set<ValidationMessage> validationMessages;

    public SchemaValidationException(Set<ValidationMessage> validationMessages) {
        super("Schema validation failed");
        this.validationMessages = validationMessages;
    }

    public Set<ValidationMessage> getValidationMessages() {
        return validationMessages;
    }
}
