package com.example.jsonvalidation.exception;

import com.example.jsonvalidation.model.ErrorResponse;
import com.networknt.schema.ValidationMessage;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(SchemaValidationException.class)
    public ResponseEntity<ErrorResponse> handleValidationException(SchemaValidationException ex) {
        Set<ValidationMessage> errors = ex.getValidationMessages();
        ErrorResponse response = new ErrorResponse("Validation Failed",
            errors.stream().map(ValidationMessage::getMessage).collect(Collectors.toList()));
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGeneralException(Exception ex) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ErrorResponse("Internal Error", List.of(ex.getMessage())));
    }
}
