package com.example.jsonvalidation.controller;

import com.example.jsonvalidation.service.LoanService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/loan")
public class LoanController {

    private final LoanService loanService;

    public LoanController(LoanService loanService) {
        this.loanService = loanService;
    }

    @PostMapping
    public ResponseEntity<?> validateLoan(@RequestBody String payload) throws Exception {
        loanService.validate(payload);
        return ResponseEntity.ok("Loan application is valid.");
    }
}
