package com.example.jsonvalidation.config;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.networknt.schema.JsonSchema;
import com.networknt.schema.JsonSchemaFactory;
import com.networknt.schema.SpecVersion;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.InputStream;

@Configuration
public class JsonSchemaConfig {

    @Bean
    public JsonSchema loanJsonSchema(ObjectMapper objectMapper) throws Exception {
        try (InputStream is = getClass().getResourceAsStream("/loan-schema.json")) {
            JsonSchemaFactory factory = JsonSchemaFactory.builder(JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V7))
                    .objectMapper(objectMapper)
                    .build();
            JsonNode jsonNode = objectMapper.readTree(is);
            return factory.getSchema(jsonNode);
        }
    }
}
